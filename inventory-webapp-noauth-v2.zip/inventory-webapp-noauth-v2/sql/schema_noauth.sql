-- Inventory Web App schema (NO AUTH)
-- ملاحظة: هذا الملف لا يفعّل RLS حتى تكون الجداول "مفتوحة" للتجربة.
-- عند تفعيل الحماية لاحقاً سنفعّل RLS ونضيف Policies.

create extension if not exists pgcrypto;

create table if not exists public.items (
  id uuid primary key default gen_random_uuid(),
  main_category text not null,
  sub_category  text not null,
  item_name     text not null,
  color_code    text not null,
  color_name    text not null,
  unit_type     text not null check (unit_type in ('kg','m')),
  description   text,
  image_path    text,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now()
);

-- منع التكرار فقط على (أساسي+فرعي+اسم الصنف+رقم اللون)
create unique index if not exists items_unique_key
on public.items (main_category, sub_category, item_name, color_code);

create index if not exists items_search_idx
on public.items (main_category, sub_category, item_name, color_name, color_code);

create table if not exists public.stock_moves (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.items(id) on delete cascade,
  move_date date not null,
  type text not null check (type in ('purchase','sale','adjustment')),
  qty_main_in  numeric not null default 0,
  qty_main_out numeric not null default 0,
  qty_rolls_in integer not null default 0,
  qty_rolls_out integer not null default 0,
  note text,
  session_id uuid,
  created_at timestamptz not null default now()
);

create index if not exists stock_moves_item_date_idx
on public.stock_moves (item_id, move_date);

create index if not exists stock_moves_type_date_idx
on public.stock_moves (type, move_date);

-- جلسات التسوية الشهرية
create table if not exists public.recon_sessions (
  id uuid primary key default gen_random_uuid(),
  recon_date date not null,
  note text,
  created_at timestamptz not null default now()
);

create index if not exists recon_sessions_date_idx
on public.recon_sessions (recon_date);

-- تفاصيل التسوية
create table if not exists public.recon_lines (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.recon_sessions(id) on delete cascade,
  recon_date date not null,
  item_id uuid not null references public.items(id) on delete cascade,
  book_qty_main numeric not null,
  book_qty_rolls integer not null,
  actual_qty_main numeric not null,
  actual_qty_rolls integer not null,
  diff_qty_main numeric not null,
  diff_qty_rolls integer not null,
  created_at timestamptz not null default now()
);

create index if not exists recon_lines_session_idx
on public.recon_lines (session_id);


-- ==========
-- صلاحيات للـ anon (بدون تسجيل دخول) لكي يعمل الموقع من المتصفح
-- ==========
grant usage on schema public to anon;

grant select, insert, update, delete on table public.items to anon;
grant select, insert, update, delete on table public.stock_moves to anon;
grant select, insert, update, delete on table public.recon_sessions to anon;
grant select, insert, update, delete on table public.recon_lines to anon;

-- للمستقبل: أي جداول جديدة في public تحصل على نفس الصلاحيات تلقائياً
alter default privileges in schema public grant select, insert, update, delete on tables to anon;
alter default privileges in schema public grant usage, select on sequences to anon;
